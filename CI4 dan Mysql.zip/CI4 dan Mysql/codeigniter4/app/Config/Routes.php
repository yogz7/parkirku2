<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->get('parkir', 'Parkir::index');
$routes->get('parkir/(:segment)', 'Parkir::show/$1');
$routes->post('parkir/create', 'Parkir::create');
$routes->post('parkir/edit/(:segment)', 'Parkir::update/$1');
$routes->delete('parkir/(:segment)', 'Parkir::delete/$1');