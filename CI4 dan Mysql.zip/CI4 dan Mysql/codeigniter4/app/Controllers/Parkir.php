<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\ParkirModel;

class Parkir extends ResourceController
{
    use ResponseTrait;
// all users
    public function index()
    {
        $model = new ParkirModel();
        $data = $model->orderBy('id_parkir', 'DESC')->findAll();
        return $this->respond($data);
    }

// single user
public function show($id = null)
{
    $model = new ParkirModel();
    $data = $model->where('id_parkir', $id)->first();
    if ($data) {
        return $this->respond($data);
    } else { 
        return $this->failNotFound('Data tidak ditemukan.');
    }
} 

// create
public function create()
{
    $model = new ParkirModel();
    $data = [
        'nama_pengguna' => $this->request->getPost('nama_pengguna'),
        'nomor_plat' => $this->request->getPost('nomor_plat'),
        'jenis_kendaraan' => $this->request->getPost('jenis_kendaraan'),
    ];
    $model->insert($data);
    $response = [
        'status'    => 208,
        'error'     => null,
        'messages'  => [
            'success' => 'Data Parkir berhasil ditambahkan.'
        ]
    ];
    return $this->respondCreated($response);
}

// update
public function update($id = null)
{
    $model = new ParkirModel();
    $data = [
        'nama_pengguna' => $this->request->getVar('nama_pengguna'),
        'nomor_plat' => $this->request->getVar('nomor_plat'),
        'jenis_kendaraan' => $this->request->getVar('jenis_kendaraan'),
    ];    
    $model->update($id, $data);
    $response = [
        'status'    => 200,
        'error'     => null,
        'messages'  => [
            'success' => 'Data Parkir berhasil diubah.'
        ]   
    ];
    return $this->respond($response);
}

// delete
public function delete($id = null)
{
    $model = new ParkirModel();
    $data = $model->where('id_parkir', $id)->delete($id);
    if ($data) {
        $model->delete($id);
        $response = [
            'status'    => 200,
            'error'     => null,
            'messages'  => [
                'success' => 'Data Parkir berhasil dihapus.'
            ]
        ];
        return $this->respondDeleted($response);
    } else {
        return $this->failNotFound('Data tidak ditemukan.');
    }
}
}
