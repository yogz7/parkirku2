<?php namespace app\Models;

use CodeIgniter\Model;

class ParkirModel extends Model
{
    protected $table = 'parkir';
    protected $primarykey = 'id_parkir';
    protected $allowedFields = ['nama_pengguna', 'nomor_plat', 'jenis_kendaraan'];
}